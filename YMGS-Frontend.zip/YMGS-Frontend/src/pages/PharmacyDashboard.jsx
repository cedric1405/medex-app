import { useState } from 'react';
import { 
  Package, 
  ShoppingCart, 
  Mail, 
  Bell, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle,
  Clock,
  DollarSign,
  Users,
  Box,
  FileText,
  Search,
  Filter,
  Plus,
  Edit,
  Trash2,
  Eye
} from 'lucide-react';

const PharmacyDashboard = () => {
  const [activeSection, setActiveSection] = useState('overview');
  const [searchTerm, setSearchTerm] = useState('');

  const getStatusColor = (status) => {
    switch(status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'shipped': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'delivered': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  const getNotificationIcon = (type) => {
    switch(type) {
      case 'order': return <ShoppingCart className="w-5 h-5 text-[#02ADEE]" />;
      case 'stock': return <AlertTriangle className="w-5 h-5 text-orange-500" />;
      case 'prescription': return <FileText className="w-5 h-5 text-purple-500" />;
      case 'email': return <Mail className="w-5 h-5 text-green-500" />;
      default: return <Bell className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm border-b dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Dashboard YMGS Pharmacy
            </h1>
            <div className="flex items-center gap-4">
              <button className="relative p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full">
                <Bell className="w-6 h-6" />
                <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full"></span>
              </button>
              <div className="w-10 h-10 bg-[#02ADEE] rounded-full flex items-center justify-center text-white">
                <Users className="w-6 h-6" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex gap-6">
          {/* Sidebar */}
          <div className="w-64 bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 h-fit sticky top-6">
            <nav className="space-y-2">
              <button
                onClick={() => setActiveSection('overview')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                  activeSection === 'overview'
                    ? 'bg-[#02ADEE] text-white'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                <TrendingUp className="w-5 h-5" />
                <span>Vue d'ensemble</span>
              </button>
              <button
                onClick={() => setActiveSection('stock')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                  activeSection === 'stock'
                    ? 'bg-[#02ADEE] text-white'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                <Package className="w-5 h-5" />
                <span>Stock Management</span>
              </button>
              <button
                onClick={() => setActiveSection('products')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                  activeSection === 'products'
                    ? 'bg-[#02ADEE] text-white'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                <Box className="w-5 h-5" />
                <span>Product Management</span>
              </button>
              <button
                onClick={() => setActiveSection('orders')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                  activeSection === 'orders'
                    ? 'bg-[#02ADEE] text-white'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                <ShoppingCart className="w-5 h-5" />
                <span>Order Management</span>
              </button>
              <button
                onClick={() => setActiveSection('email')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                  activeSection === 'email'
                    ? 'bg-[#02ADEE] text-white'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
              >
                <Mail className="w-5 h-5" />
                <span>Email & Notifications</span>
              </button>
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Overview Section */}
            {activeSection === 'overview' && (
              <div className="space-y-6">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Chiffre d'affaires</p>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                          0 FCFA
                        </p>
                      </div>
                      <div className="bg-green-100 dark:bg-green-900 p-3 rounded-full">
                        <DollarSign className="w-6 h-6 text-green-600 dark:text-green-300" />
                      </div>
                    </div>
                    <div className="mt-4 flex items-center text-sm text-green-600">
                      <TrendingUp className="w-4 h-4 mr-1" />
                      <span>+0% ce mois</span>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Commandes</p>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">0</p>
                      </div>
                      <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-full">
                        <ShoppingCart className="w-6 h-6 text-blue-600 dark:text-blue-300" />
                      </div>
                    </div>
                    <div className="mt-4 flex items-center text-sm text-blue-600">
                      <Clock className="w-4 h-4 mr-1" />
                      <span>0 en attente</span>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Produits</p>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">0</p>
                      </div>
                      <div className="bg-purple-100 dark:bg-purple-900 p-3 rounded-full">
                        <Package className="w-6 h-6 text-purple-600 dark:text-purple-300" />
                      </div>
                    </div>
                    <div className="mt-4 flex items-center text-sm text-purple-600">
                      <CheckCircle className="w-4 h-4 mr-1" />
                      <span>Tous actifs</span>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Stock faible</p>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">0</p>
                      </div>
                      <div className="bg-orange-100 dark:bg-orange-900 p-3 rounded-full">
                        <AlertTriangle className="w-6 h-6 text-orange-600 dark:text-orange-300" />
                      </div>
                    </div>
                    <div className="mt-4 flex items-center text-sm text-orange-600">
                      <AlertTriangle className="w-4 h-4 mr-1" />
                      <span>Aucune action requise</span>
                    </div>
                  </div>
                </div>

                {/* Recent Orders & Low Stock */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Recent Orders */}
                  <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                      Commandes récentes
                    </h3>
                    <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                      <ShoppingCart className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Aucune commande récente</p>
                    </div>
                  </div>

                  {/* Low Stock Products */}
                  <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                      Stock faible - Action requise
                    </h3>
                    <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                      <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Aucun produit en stock faible</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Stock Management Section */}
            {activeSection === 'stock' && (
              <div className="space-y-6">
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                      Gestion du Stock
                    </h2>
                    <button className="bg-[#02ADEE] text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#0296d1]">
                      <Plus className="w-5 h-5" />
                      Ajouter stock
                    </button>
                  </div>

                  <div className="mb-4 flex gap-4">
                    <div className="flex-1 relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                      <input
                        type="text"
                        placeholder="Rechercher un produit..."
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <button className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg flex items-center gap-2 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700">
                      <Filter className="w-5 h-5" />
                      Filtrer
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 dark:bg-gray-700">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            Produit
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            Catégorie
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            Stock actuel
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            Stock minimum
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            Statut
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                        <tr>
                          <td colSpan="6" className="px-6 py-12 text-center text-gray-500 dark:text-gray-400">
                            <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
                            <p>Aucun produit en stock</p>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* Product Management Section */}
            {activeSection === 'products' && (
              <div className="space-y-6">
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                      Gestion des Produits
                    </h2>
                    <button className="bg-[#02ADEE] text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#0296d1]">
                      <Plus className="w-5 h-5" />
                      Nouveau produit
                    </button>
                  </div>

                  <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                    <Box className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg mb-2">Aucun produit disponible</p>
                    <p className="text-sm">Cliquez sur "Nouveau produit" pour commencer</p>
                  </div>
                </div>
              </div>
            )}

            {/* Orders Management Section */}
            {activeSection === 'orders' && (
              <div className="space-y-6">
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
                    Gestion des Commandes
                  </h2>

                  <div className="mb-4 flex gap-4">
                    <button className="px-4 py-2 bg-[#02ADEE] text-white rounded-lg">
                      Toutes
                    </button>
                    <button className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700">
                      En attente
                    </button>
                    <button className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700">
                      Expédiées
                    </button>
                    <button className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700">
                      Livrées
                    </button>
                  </div>

                  <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                    <ShoppingCart className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg mb-2">Aucune commande</p>
                    <p className="text-sm">Les commandes apparaîtront ici</p>
                  </div>
                </div>
              </div>
            )}

            {/* Email & Notifications Section */}
            {activeSection === 'email' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Notifications */}
                  <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
                      Notifications récentes
                    </h2>
                    <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                      <Bell className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Aucune notification</p>
                    </div>
                  </div>

                  {/* Email Management */}
                  <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
                      Gestion des Emails
                    </h2>
                    <div className="space-y-4">
                      <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold text-gray-900 dark:text-white">
                            Messages non lus
                          </h3>
                          <span className="bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300 px-3 py-1 rounded-full text-sm font-medium">
                            0
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                          Aucun message en attente
                        </p>
                        <button className="w-full bg-[#02ADEE] text-white py-2 rounded-lg hover:bg-[#0296d1]">
                          Consulter la boîte de réception
                        </button>
                      </div>

                      <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                          Campagnes email
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                          Envoyez des promotions et newsletters à vos clients
                        </p>
                        <button className="w-full border border-[#02ADEE] text-[#02ADEE] py-2 rounded-lg hover:bg-[#02ADEE] hover:text-white transition-colors">
                          Créer une campagne
                        </button>
                      </div>

                      <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                          Modèles d'emails
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                          Gérez vos modèles d'emails automatiques
                        </p>
                        <button className="w-full border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
                          Gérer les modèles
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Email Templates Section */}
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
                    Modèles d'emails
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer">
                      <div className="bg-green-100 dark:bg-green-900 w-12 h-12 rounded-lg flex items-center justify-center mb-3">
                        <CheckCircle className="w-6 h-6 text-green-600 dark:text-green-300" />
                      </div>
                      <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                        Confirmation de commande
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                        Email automatique envoyé après chaque commande
                      </p>
                      <button className="text-sm text-[#02ADEE] hover:underline">
                        Modifier le modèle
                      </button>
                    </div>

                    <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer">
                      <div className="bg-blue-100 dark:bg-blue-900 w-12 h-12 rounded-lg flex items-center justify-center mb-3">
                        <ShoppingCart className="w-6 h-6 text-blue-600 dark:text-blue-300" />
                      </div>
                      <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                        Expédition de commande
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                        Notification d'expédition avec tracking
                      </p>
                      <button className="text-sm text-[#02ADEE] hover:underline">
                        Modifier le modèle
                      </button>
                    </div>

                    <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer">
                      <div className="bg-purple-100 dark:bg-purple-900 w-12 h-12 rounded-lg flex items-center justify-center mb-3">
                        <FileText className="w-6 h-6 text-purple-600 dark:text-purple-300" />
                      </div>
                      <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                        Rappel ordonnance
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                        Rappel pour renouvellement d'ordonnance
                      </p>
                      <button className="text-sm text-[#02ADEE] hover:underline">
                        Modifier le modèle
                      </button>
                    </div>
                  </div>
                </div>

                {/* Recent Email Activity */}
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
                    Activité email récente
                  </h2>
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <Mail className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>Aucune activité email récente</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PharmacyDashboard;